﻿=== Pikachu Cute Cursor Set ===

By: HusenPo (http://www.rw-designer.com/user/38863)

Download: http://www.rw-designer.com/cursor-set/pokemon-lightning

Author's decription:

Pikachu (Japanese: ピカチュウ Hepburn: Pikachū?) /ˈpiːkəˌtʃuː/ is one of the species of Pokémon creatures from the Pokémon media franchise — a collection of video games, anime, manga, books, trading cards, and other media created by Satoshi Tajiri. Pikachu fight other Pokémon in battles central to the anime, manga, and games of the series.[1] Pikachu is widely considered the most popular Pokémon, largely because a Pikachu is a central character in the Pokémon anime series.[2] Pikachu is regarded as the official mascot of the Pokémon franchise, and has become an icon of Japanese culture in recent years.
Pikachu evolves from a Pichu when it levels up with high happiness, and evolves into a Raichu with a "Thunderstone". Within the world of the Pokémon franchise, Pikachu are often found in houses, forests,[3] plains, and occasionally near mountains, islands, and electrical sources (such as power plants), on most continents throughout the fictional world. As an Electric-type Pokémon, Pikachu can store electricity in its cheeks and release it in lightning-based attacks.[4] Its Pokedex entry states that it is a Mouse Pokémon.
Description from: http://en.wikipedia.org/wiki/Pikachu

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.